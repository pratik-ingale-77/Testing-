const mongoose = require("mongoose");

// A Department represents a civic body that resolves a specific type of complaint
// e.g. "Roads Department" handles Pothole/Road Damage,
//      "Sanitation Department" handles Garbage, etc.
const departmentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    // Which complaint categories this department is responsible for
    handlesCategories: [
      {
        type: String,
        enum: ["Pothole", "Garbage", "Streetlight", "Water Leakage", "Road Damage", "Other"],
      },
    ],
    contactEmail: {
      type: String,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Department", departmentSchema);
