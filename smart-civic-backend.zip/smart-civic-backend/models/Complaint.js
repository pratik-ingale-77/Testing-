const mongoose = require("mongoose");

const complaintSchema = new mongoose.Schema(
  {
    // Who reported it
    reportedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // Path/URL to the uploaded photo
    imageUrl: {
      type: String,
      required: true,
    },

    // ----- Filled in automatically by the AI classification service -----
    category: {
      type: String,
      enum: ["Pothole", "Garbage", "Streetlight", "Water Leakage", "Road Damage", "Other"],
      default: "Other",
    },
    priority: {
      type: String,
      enum: ["Low", "Medium", "High"],
      default: "Medium",
    },
    aiDescription: {
      type: String, // short explanation the AI gave for its classification
    },
    aiConfidence: {
      type: Number, // 0-1, how confident the AI was
    },

    // ----- Location captured from the user's device -----
    location: {
      latitude: { type: Number, required: true },
      longitude: { type: Number, required: true },
      address: { type: String }, // human-readable address, e.g. "XYZ Road"
    },

    // ----- Routing & status tracking -----
    assignedDepartment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Department",
      default: null,
    },
    status: {
      type: String,
      enum: ["Pending", "In Progress", "Resolved", "Rejected"],
      default: "Pending",
    },
    // Free-text notes department staff can add when updating status
    statusNotes: {
      type: String,
    },
    resolvedAt: {
      type: Date,
    },
  },
  { timestamps: true } // adds createdAt (when reported) and updatedAt automatically
);

module.exports = mongoose.model("Complaint", complaintSchema);
