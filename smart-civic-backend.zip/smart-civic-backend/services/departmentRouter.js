const Department = require("../models/Department");

/**
 * Given a complaint's category, finds the Department responsible for it.
 * Returns the Department document, or null if none is configured yet.
 */
const findDepartmentForCategory = async (category) => {
  const department = await Department.findOne({ handlesCategories: category });
  return department;
};

module.exports = { findDepartmentForCategory };
