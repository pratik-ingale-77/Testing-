const fs = require("fs");
const axios = require("axios");

/**
 * Sends the complaint photo to Claude (Anthropic's AI model) and asks it to
 * classify the civic issue in the image.
 *
 * Returns: { category, priority, description, confidence }
 */
const classifyComplaintImage = async (imagePath, mimeType) => {
  const imageBuffer = fs.readFileSync(imagePath);
  const base64Image = imageBuffer.toString("base64");

  const prompt = `You are helping a civic complaint app classify a photo of a public infrastructure issue.
Look at the image and respond with ONLY a JSON object (no other text, no markdown fences) in exactly this format:
{
  "category": "Pothole" | "Garbage" | "Streetlight" | "Water Leakage" | "Road Damage" | "Other",
  "priority": "Low" | "Medium" | "High",
  "description": "one short sentence describing what you see",
  "confidence": a number between 0 and 1
}
Priority guidance: High = safety hazard or blocks daily life (deep pothole, major leak, live wire risk),
Medium = noticeable problem but not urgent, Low = minor/cosmetic issue.
If the image does not show a civic issue at all, use category "Other" and priority "Low".`;

  try {
    const response = await axios.post(
      "https://api.anthropic.com/v1/messages",
      {
        model: "claude-sonnet-4-6",
        max_tokens: 300,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "image",
                source: {
                  type: "base64",
                  media_type: mimeType,
                  data: base64Image,
                },
              },
              { type: "text", text: prompt },
            ],
          },
        ],
      },
      {
        headers: {
          "x-api-key": process.env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
        },
      }
    );

    const textBlock = response.data.content.find((block) => block.type === "text");
    const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
    const result = JSON.parse(cleaned);

    return {
      category: result.category || "Other",
      priority: result.priority || "Medium",
      description: result.description || "",
      confidence: typeof result.confidence === "number" ? result.confidence : 0.5,
    };
  } catch (err) {
    console.error("AI classification failed:", err.response?.data || err.message);
    // Fail safe: if AI call fails, don't block the complaint submission —
    // fall back to a default so a human can review/reclassify it manually
    return {
      category: "Other",
      priority: "Medium",
      description: "Could not auto-classify - needs manual review",
      confidence: 0,
    };
  }
};

module.exports = { classifyComplaintImage };
