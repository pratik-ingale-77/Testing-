const Department = require("../models/Department");

// POST /api/departments  (admin only)
const createDepartment = async (req, res) => {
  try {
    const { name, handlesCategories, contactEmail } = req.body;
    const department = await Department.create({ name, handlesCategories, contactEmail });
    res.status(201).json(department);
  } catch (err) {
    res.status(500).json({ message: "Failed to create department", error: err.message });
  }
};

// GET /api/departments
const getDepartments = async (req, res) => {
  try {
    const departments = await Department.find();
    res.json(departments);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch departments", error: err.message });
  }
};

module.exports = { createDepartment, getDepartments };
