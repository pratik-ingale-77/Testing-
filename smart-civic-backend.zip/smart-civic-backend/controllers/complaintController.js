const Complaint = require("../models/Complaint");
const { classifyComplaintImage } = require("../services/aiService");
const { findDepartmentForCategory } = require("../services/departmentRouter");

// POST /api/complaints
// Flow: photo uploaded -> AI classifies it -> location attached -> department assigned -> saved
const createComplaint = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "A photo is required to file a complaint" });
    }

    const { latitude, longitude, address } = req.body;
    if (!latitude || !longitude) {
      return res.status(400).json({ message: "Location (latitude & longitude) is required" });
    }

    // 1. AI identifies the problem from the photo
    const aiResult = await classifyComplaintImage(req.file.path, req.file.mimetype);

    // 2. Find which department handles this category
    const department = await findDepartmentForCategory(aiResult.category);

    // 3. Save the complaint with everything filled in
    const complaint = await Complaint.create({
      reportedBy: req.user._id,
      imageUrl: `/uploads/${req.file.filename}`,
      category: aiResult.category,
      priority: aiResult.priority,
      aiDescription: aiResult.description,
      aiConfidence: aiResult.confidence,
      location: { latitude, longitude, address },
      assignedDepartment: department ? department._id : null,
      status: "Pending",
    });

    res.status(201).json({
      message: "Complaint filed successfully",
      complaint,
    });
  } catch (err) {
    res.status(500).json({ message: "Failed to file complaint", error: err.message });
  }
};

// GET /api/complaints
// Citizens see only their own complaints; staff/admin see everything (optionally filtered by their department)
const getComplaints = async (req, res) => {
  try {
    let filter = {};

    if (req.user.role === "citizen") {
      filter.reportedBy = req.user._id;
    } else if (req.user.role === "staff") {
      filter.assignedDepartment = req.user.department;
    }
    // admin gets no filter -> sees everything

    // Optional query filters, e.g. /api/complaints?status=Pending&category=Pothole
    if (req.query.status) filter.status = req.query.status;
    if (req.query.category) filter.category = req.query.category;

    const complaints = await Complaint.find(filter)
      .populate("reportedBy", "name email")
      .populate("assignedDepartment", "name")
      .sort({ createdAt: -1 });

    res.json(complaints);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch complaints", error: err.message });
  }
};

// GET /api/complaints/:id
const getComplaintById = async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id)
      .populate("reportedBy", "name email")
      .populate("assignedDepartment", "name");

    if (!complaint) {
      return res.status(404).json({ message: "Complaint not found" });
    }

    res.json(complaint);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch complaint", error: err.message });
  }
};

// PATCH /api/complaints/:id/status
// Only staff/admin can update status (e.g. Pending -> In Progress -> Resolved)
const updateComplaintStatus = async (req, res) => {
  try {
    const { status, statusNotes } = req.body;
    const complaint = await Complaint.findById(req.params.id);

    if (!complaint) {
      return res.status(404).json({ message: "Complaint not found" });
    }

    complaint.status = status;
    if (statusNotes) complaint.statusNotes = statusNotes;
    if (status === "Resolved") complaint.resolvedAt = new Date();

    await complaint.save();

    res.json({ message: "Status updated", complaint });
  } catch (err) {
    res.status(500).json({ message: "Failed to update status", error: err.message });
  }
};

module.exports = { createComplaint, getComplaints, getComplaintById, updateComplaintStatus };
