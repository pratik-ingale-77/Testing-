const express = require("express");
const router = express.Router();
const { protect, authorize } = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  createComplaint,
  getComplaints,
  getComplaintById,
  updateComplaintStatus,
} = require("../controllers/complaintController");

// All complaint routes require login
router.use(protect);

// Citizen files a new complaint (photo upload, field name must be "photo")
router.post("/", upload.single("photo"), createComplaint);

// List complaints (filtered by role automatically inside the controller)
router.get("/", getComplaints);

// Get one complaint by id
router.get("/:id", getComplaintById);

// Only staff/admin can change status
router.patch("/:id/status", authorize("staff", "admin"), updateComplaintStatus);

module.exports = router;
