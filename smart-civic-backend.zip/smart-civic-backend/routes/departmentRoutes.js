const express = require("express");
const router = express.Router();
const { protect, authorize } = require("../middleware/auth");
const { createDepartment, getDepartments } = require("../controllers/departmentController");

// Anyone logged in can view departments
router.get("/", protect, getDepartments);

// Only admin can create new departments
router.post("/", protect, authorize("admin"), createDepartment);

module.exports = router;
