// Run this once after setting up MongoDB to create the default departments:
//   node seedDepartments.js
require("dotenv").config();
const mongoose = require("mongoose");
const Department = require("./models/Department");

const departments = [
  { name: "Roads Department", handlesCategories: ["Pothole", "Road Damage"], contactEmail: "roads@civic.gov" },
  { name: "Sanitation Department", handlesCategories: ["Garbage"], contactEmail: "sanitation@civic.gov" },
  { name: "Electricity Department", handlesCategories: ["Streetlight"], contactEmail: "electricity@civic.gov" },
  { name: "Water Department", handlesCategories: ["Water Leakage"], contactEmail: "water@civic.gov" },
  { name: "General Department", handlesCategories: ["Other"], contactEmail: "general@civic.gov" },
];

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Department.deleteMany({});
  await Department.insertMany(departments);
  console.log("✅ Departments seeded:", departments.map((d) => d.name).join(", "));
  await mongoose.disconnect();
};

seed().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});
