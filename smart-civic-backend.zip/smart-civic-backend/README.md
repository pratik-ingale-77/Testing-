# Smart Civic Complaint App — Backend

Backend for a civic issue reporting app. A citizen photographs a problem
(pothole, garbage, broken streetlight, water leakage), the AI identifies
the issue and its priority, the location is captured automatically, and
the complaint is routed to the right municipal department.

## Tech Stack
- **Node.js + Express** — REST API server
- **MongoDB + Mongoose** — database
- **Multer** — photo upload handling
- **Claude (Anthropic API)** — AI image classification (category + priority)
- **JWT + bcrypt** — authentication

## How a complaint flows through the system
1. Citizen logs in and uploads a photo + their current GPS location.
2. `POST /api/complaints` saves the photo, then sends it to Claude's vision
   API asking it to classify the issue (see `services/aiService.js`).
3. The AI returns a category (e.g. "Pothole"), a priority (Low/Medium/High),
   and a short description.
4. `services/departmentRouter.js` looks up which `Department` handles that
   category and auto-assigns the complaint.
5. The complaint is saved with status `Pending`. Department staff can later
   update its status to `In Progress` or `Resolved`.

## Project Structure
```
config/db.js              MongoDB connection
models/                   Mongoose schemas: User, Department, Complaint
middleware/upload.js      Multer config for photo uploads
middleware/auth.js        JWT auth + role-based access control
services/aiService.js     Calls Claude to classify the complaint photo
services/departmentRouter.js   Maps category -> Department
controllers/              Route handler logic
routes/                   Express route definitions
server.js                 App entry point
seedDepartments.js        One-time script to create default departments
```

## Setup

1. **Install dependencies**
   ```
   npm install
   ```

2. **Configure environment variables**
   Copy `.env.example` to `.env` and fill in:
   - `MONGO_URI` — get a free cluster at https://www.mongodb.com/cloud/atlas, or run MongoDB locally
   - `JWT_SECRET` — any long random string
   - `ANTHROPIC_API_KEY` — get one at https://console.anthropic.com/

3. **Seed the default departments** (Roads, Sanitation, Electricity, Water, General)
   ```
   node seedDepartments.js
   ```

4. **Run the server**
   ```
   npm run dev
   ```
   Server starts at `http://localhost:5000`

## API Reference

### Auth
| Method | Endpoint | Body | Description |
|---|---|---|---|
| POST | `/api/auth/register` | `{ name, email, password, role }` | role: "citizen" or "staff" |
| POST | `/api/auth/login` | `{ email, password }` | Returns a JWT token |

All routes below require header: `Authorization: Bearer <token>`

### Complaints
| Method | Endpoint | Body | Description |
|---|---|---|---|
| POST | `/api/complaints` | form-data: `photo` (file), `latitude`, `longitude`, `address` | Files a new complaint — AI classifies it automatically |
| GET | `/api/complaints` | — | Citizens see their own; staff see their department's; admin sees all. Optional query: `?status=Pending&category=Pothole` |
| GET | `/api/complaints/:id` | — | Get one complaint |
| PATCH | `/api/complaints/:id/status` | `{ status, statusNotes }` | Staff/admin only |

### Departments
| Method | Endpoint | Body | Description |
|---|---|---|---|
| GET | `/api/departments` | — | List all departments |
| POST | `/api/departments` | `{ name, handlesCategories, contactEmail }` | Admin only |

## Testing with curl

```bash
# Register a citizen
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Asha","email":"asha@test.com","password":"pass123","role":"citizen"}'

# File a complaint (replace TOKEN and the image path)
curl -X POST http://localhost:5000/api/complaints \
  -H "Authorization: Bearer TOKEN" \
  -F "photo=@/path/to/pothole.jpg" \
  -F "latitude=19.0760" \
  -F "longitude=72.8777" \
  -F "address=XYZ Road"
```

## Notes for the team
- Frontend just needs to hit these REST endpoints — works with any framework (React, Flutter, etc.)
- The AI call in `aiService.js` fails gracefully: if the API call errors out, the complaint still gets saved (category "Other") so a human can fix it later — nothing is ever lost.
- To add a new complaint category, update the `enum` list in `models/Complaint.js` and `models/Department.js`, and add a matching department via the seed script or `POST /api/departments`.
