const mongoose = require("mongoose");

// Connects to MongoDB using the URI from .env
// Called once when the server starts (see server.js)
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ MongoDB connected successfully");
  } catch (err) {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1); // stop the server if DB connection fails
  }
};

module.exports = connectDB;
